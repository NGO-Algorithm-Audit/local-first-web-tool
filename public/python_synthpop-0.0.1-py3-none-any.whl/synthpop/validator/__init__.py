from synthpop.validator.validator import Validator
