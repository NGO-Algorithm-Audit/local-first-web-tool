from synthpop.processor.processor import Processor
from synthpop.processor.processor import NAN_KEY, NUMTOCAT_KEY
