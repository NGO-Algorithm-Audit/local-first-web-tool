NUM_COLS_DTYPES = ['int', 'float', 'datetime']
CAT_COLS_DTYPES = ['category', 'bool']

from synthpop.synthpop import Synthpop
