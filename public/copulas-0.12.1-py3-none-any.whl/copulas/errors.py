"""Copulas Exceptions."""


class NotFittedError(Exception):
    """NotFittedError class."""
