

class Validator:
    def __init__(self) -> None:
        pass